/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author nmal.bscs15seecs
 */
public class JavaApplication1 {
      private int orderprice;
      private String[]Order;
      private String address;
      private String[] cook;
      private int time;
      
      void JavaApplication()
      {
          orderprice=0;
          address=null;
          cook=new String[4];
      }
      void SetOrder(String[]order,int y)
      {
          int l =y;
           Order=new String[l];
           for(int i=0;i<y;i++)
           {
               Order[i]=order[i];
           }
      }
      void ViewCook()
      {
          int l=Order.length;
          int y=4;
          for(int i=0;i<l  && l<8;i++)
          {
              if(l>4)
              {
                  
              System.out.print("Cook" +(i-y)+ "is working on      "+Order[i]);
              System.out.print("\n");
              }
              
              System.out.print("Cook" +i+ "is working on      "+Order[i]);
              System.out.print("\n");
          }
      }
      void SetOrderPrice(int price)
      {
          orderprice=price;
      }
      void printOrder()
      {
          int l = Order.length;
          System.out.print("Print the order\n\n");
          for(int i=0;i<l;i++)
          {
              System.out.print(Order[i]);
              System.out.print("\n"); 
          }
          System.out.print("Order of address   ");
          System.out.print(address);
          System.out.print("Order Price   ");
          System.out.print(orderprice);
          System.out.print("\n");
      }
      void setaddress()
      {
          Scanner sc=new Scanner(System.in);
         System.out.print(" Enter your address of delivery   ");
         address=sc.nextLine(); 
      }
      void pickup()
      {
          Scanner sc=new Scanner(System.in);
         System.out.print(" Enter time for pickup between 11am to 22  ");
         time=sc.nextInt();
          if(time<11 && time >22)
          {
              System.out.print(" Shop IS Closed   \n\n");
          }
          else
               System.out.print(" your delivery will be in 30 mintues    \n\n");
              
      }
      
   
    public static void main(String[] args) {
        
        JavaApplication1 obj=new JavaApplication1();
        Scanner sc=new Scanner(System.in);
        int y=0;
        int price=0;
        String order[]=new String[15];//declaration and instantiation  
        // TODO code application logic here
        String address;
        System.out.print("1.karai     450\n");
        System.out.print("2.Soup    250\n");
        System.out.print("3.pepper Popper    200\n");
        System.out.print("4.Glazed Chicken Wings   300\n");
        System.out.print("5.One pot lasme  100\n");
        System.out.print("6.Easy Meatloaf  500\n");
        System.out.print("7.Simple Baked Chicken Breasts    250\n");
        System.out.print("8.World's Best Lasagna   350\n");
        System.out.print("9.Crispy and Tender Baked Chicken Thighs   450\n");
        System.out.print("10.Homemade Mac and Cheese   1000 \n");
        System.out.print("11.Stuffed Peppers   700\n");
        System.out.print("12.CHINESE FRIED RICE   100\n");
        System.out.print("13.TACO BELL QUESADILLAS   100\n");
        System.out.print("14.EASY FRIED RICE     100\n");
        System.out.print("1.MOZZARELLA STICKS   150\n\n");
        System.out.print("Select one value from above list\n");
        int x;
        x=sc.nextInt();
        char c='y';
        for(int i=0;i<15 && c=='y';i++)
        {
         switch(x){  
    case 1:order[i]="karai     450";price+=450; break;  
    case 2:order[i]="Soup   250";price+=250;break;  
    case 3: order[i]="pepperPopper   200";price+=200;break;
    case 4:order[i]="Glazed Chicken Wings   300";price+=300;break;  
    case 5: order[i]="one pot lasme   100";price+=100;break;
    case 6:order[i]="Easy Meatloaf   500";price+=500;break;  
    case 7:order[i]="Simple Baked Chicken Breasts  250";price+=250;break;  
    case 8: order[i]="World's Best Lasagna   350";price+=350;break;
    case 9:order[i]="Crispy and Tender Baked Chicken Thighs  450";price+=450;break;  
    case 10: order[i]="Homemade Mac and Cheese    1000";price+=1000;break;
    case 11:order[i]="Stuffed Peppers    700";price+=700;break;  
    case 12:order[i]="CHINESE FRIED RICE   100";price+=100;break;  
    case 13: order[i]="TACO BELL QUESADILLAS   100";price+=100;break;
    case 14:order[i]="EASY FRIED RICE   100";price+=100;break;  
    case 15: order[i]="MOZZARELLA STICKSn   150";price+=150;break; 
    default:System.out.println("invalid");  
    }
         y=y+1;
           System.out.print("do you select another item\n");
           c=sc.next().charAt(0);
         System.out.print("Select one value from above list\n");
        x=sc.nextInt(); 
        }
  
        System.out.print("1. For Order Delivery  \n");
        System.out.print("2. For Order Pickup  \n");
        x=sc.nextInt();
       switch(x)
       {  
       case 1:obj.setaddress();break;  
       case 2:obj.pickup();break;
       }
        obj.SetOrder(order,y);
        obj.SetOrderPrice(price);
        obj.printOrder();
        obj.ViewCook();
        
    }
    
}
